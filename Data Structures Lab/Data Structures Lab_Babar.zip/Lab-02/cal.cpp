#include <iostream>
#include <cstdlib>
using namespace std;

int main(){
	system("q2.exe");
//	cout << getenv("PATH");
	return 0;
}
